hey.. terimakasih sudah mendownload source code aio

1. silahkan buka script generate.php yang ada di scripts/generate.php
2. isi api code kamu ke dalam variabel apikey. jika kamu blum punya api code, silahkan register di http://aio.owplus.com
3. tolong copyright nya jangan di buang ya :D