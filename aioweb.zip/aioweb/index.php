<!DOCTYPE html>
<html>
<head>
	<title>Welcome To All In One</title>
	<link rel="stylesheet" type="text/css" href="css/all.css">
	<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
	<script type="text/javascript">
	function another(){
		$("#main-wrap-result-generate-user").hide();
		$("#main-form-wrap-data").show();
		$("#title-aio").html("Insert a valid URL to the form!");
	}

		function generateDownload(){

			var hostname;
			var urlInput = $.trim($("#ipt-url-input").val());

			if(urlInput.indexOf("://") > -1){
				hostname = urlInput.split("/")[2];
			}else{
				hostname = hostname.split("/")[0];
			}

			var urlVariable = hostname.split(":")[0];

			if(urlInput.length == 0 || urlInput.length == null){
				alert("Please insert a valid URL!!");
				$("#btn-generate").css("background", "#53bbb4");
				$("#btn-generate").html("GENERATE DOWNLOAD");
			}else{

				$("#btn-generate").html('<img src="images/loading-icon.gif" style="width: 20px; height: 20px;">');
				$("#btn-generate").css("background", "#fff");	
					
				$.post("scripts/generate.php", {urlInput:urlInput, urlVariable:urlVariable}, function(data){

					if(data == "Invalid URL!!, Please insert a valid url."){
						alert("Invalid URL!!, Please insert a valid url.");
						$("#btn-generate").css("background", "#53bbb4");
						$("#btn-generate").html("GENERATE DOWNLOAD");
					}else{
						$("#title-aio").html("Ready to download. <span style='cursor: pointer; color: #4aaee7;' onclick='another()'>Download Another</span>");
						$("#main-wrap-result-generate-user").show();
						$("#main-wrap-result-generate-user").html(data);
						$("#main-form-wrap-data").hide();
						$("#ipt-url-input").val("");
						$("#btn-generate").css("background", "#53bbb4");
						$("#btn-generate").html("GENERATE DOWNLOAD");

					}

				
				});

			}

			


		}
	</script>
</head>
<body>



<div id="main-div-wrap-body-aio">
	<div id="wrap-data-body-aio-download">

		<div id="top-body-aio-download-wrap">
			<div id="main-wrap-download-top">
				<div id="left-img-aio-download-logo">
					<img src="images/logo.png" draggable="false">
				</div>
				<div id="right-form-download-aio">
					<div id="aio-text-logo">
						<h2>AIO DOWNLOADER</h2>
						<p id="title-aio">Insert a valid URL to the form!</p>
					</div>
					<div id="main-form-wrap-data">
						
						<input type="text" placeholder="Insert URL Here" id="ipt-url-input"><br>
						<button id="btn-generate" onclick="generateDownload()">GENERATE DOWNLOAD</button><br><br>

						<p><img src="images/fb.png" draggable="false"></p>
						<p><img src="images/sc.png" draggable="false"></p>
						<p><img src="images/yt.png" draggable="false"></p>
						<p><img src="images/ig.png" draggable="false"></p>
					</div>

					<div id="main-wrap-result-generate-user" style="display: none;"></div>

				</div>
			</div>
		</div>





		<div id="bottom-footer-aio-download">
			<div id="list-aio-footer-download">
				<p id="api"><a href="http://aio.owplus.com" style="color: #555; outline: none;" target="_blank">API</a></p>
				<p>&copy; <?php echo date("Y"); ?> Gusfahmi Alghazali Caniago.</p>
			</div>
		</div>




	</div>
</div>


</body>
</html>