<?php
error_reporting(0);
// mysql_connect("mysql.idhostinger.com", "u535372609_aio", "gusfahmi10081996");
// mysql_select_db("u535372609_aio");

require 'PHPMailer/PHPMailerAutoload.php';

if(!empty($_SERVER["HTTP_CLIENT_IP"])){
	$ip = $_SERVER["HTTP_CLIENT_IP"];
}else if(!empty($_SERVER["HTTP_X_FORWARDER_FOR"])){
	$ip = $_SERVER["HTTP_X_FORWARDER_FOR"];
}else{
	$ip = $_SERVER["REMOTE_ADDR"];
}


$email = $_POST['email'];


if($email == ""){
	die("Get out!!");
}else{


$time_register = date("d F Y H:i:s");

$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
$code = substr(str_shuffle($chars), 0, 30);


$check_email = mysql_query("SELECT * FROM api_users WHERE email='$email' ORDER BY id DESC LIMIT 1");
$num = mysql_num_rows($check_email);
if($num == 0){


$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'mx1.idhostinger.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'aio@owplus.com';                 // SMTP username
$mail->Password = 'gusfahmi10081996';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom('aio@owplus.com', 'AIO API Registration');
$mail->addAddress($email, 'AIO API Registration');     // Add a recipient
// $mail->addAddress('ellen@example.com');               // Name is optional
// $mail->addReplyTo('info@example.com', 'Information');
// $mail->addCC('cc@example.com');
// $mail->addBCC('bcc@example.com');

//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'AIO API Registration';
$mail->Body    = 'Congragulation you are now registered with our API <br>Your API code is '.$code;

if(!$mail->send()) {
    
} else {
    echo 'Message has been sent';
    $insert_user = mysql_query("INSERT INTO api_users VALUES('','$ip','$email','$time_register','$code','0','Limited')");
}


}else{

	echo "Email already exist!!";

}
}
?>