<?php
error_reporting(0);
$urlInput = $_POST['urlInput'];
$urlVariable = $_POST['urlVariable'];

if($urlInput == null || $urlInput == "" || $urlVariable == null || $urlVariable == ""){

	die("Get out mother fucker!!");

}else{


// isi api key ini dengan api key kamu
$apiKey = "";

	if($urlVariable == "www.instagram.com" || $urlVariable == "instagram.com"){

		$apiGenerate = file_get_contents("http://www.owplus.com/api/downloader/generate?type=Instagram&url_input=".$urlInput."&api_code=".$apiKey."");
		$response = json_encode($apiGenerate);

		if($response == "false"){

			echo "Invalid URL!!, Please insert a valid url.";

		}else{

			$obj = json_decode($apiGenerate);

			$thumbnail = $obj->result->thumbnail;
			$title = $obj->result->title;
			$url_download = $obj->result->url_download;

			if (strlen($title) > 28) {
				$titlePost = substr($title, 0, 25)." ..";
			}else if (strlen($title) < 28){
				$titlePost = $title;
			}

			echo '<div id="wrap-result-generate">

					<div id="left-img-thumbnail-generate-result">
						<img src="'.$thumbnail.'">
					</div>
					<div id="text-description-result">
						<p id="title-result">'.$titlePost.'</p>
						<p id="method-download">Instagram</p>
	
						<a href="'.$url_download.'" download>
						<button id="btn-download" onclick="download()">
							DOWNLOAD
						</button>
						</a>
					</div>

				</div>';

		}





	}else if($urlVariable == "www.youtube.com" || $urlVariable == "youtube.com"){



		$apiGenerate = file_get_contents("http://www.owplus.com/api/downloader/generate?type=Youtube&url_input=".$urlInput."&api_code=".$apiKey."");
		$response = json_encode($apiGenerate);

		if($response == "false"){

			echo "Invalid URL!!, Please insert a valid url.";

		}else{

			$obj = json_decode($apiGenerate);

			$thumbnail = $obj[0]->thumbnail;
			$title = $obj[0]->title;
			$url_download = $obj[0]->url;

			if (strlen($title) > 28) {
				$titlePost = substr($title, 0, 25)." ..";
			}else if (strlen($title) < 28){
				$titlePost = $title;
			}

			echo '<div id="wrap-result-generate">

					<div id="left-img-thumbnail-generate-result">
						<img src="'.$thumbnail.'">
					</div>
					<div id="text-description-result">
						<p id="title-result">'.$titlePost.'</p>
						<p id="method-download">Youtube</p>
						<a href="'.$url_download.'" download>
						<button id="btn-download" onclick="download()">
							DOWNLOAD
						</button>
						</a>
					</div>

				</div>';

		}



	}else if($urlVariable == "www.facebook.com" || $urlVariable == "facebook.com" || $urlVariable == "web.facebook.com"){


		$apiGenerate = file_get_contents("http://www.owplus.com/api/downloader/generate?type=Facebook&url_input=".$urlInput."&api_code=".$apiKey."");
		$response = json_encode($apiGenerate);

		if($response == "false"){

			echo "Invalid URL!!, Please insert a valid url.";

		}else{

			$obj = json_decode($apiGenerate);

			$thumbnail = $obj->result->thumbnail;
			$title = $obj->result->title;
			$url_download = $obj->result->url_download;

			if (strlen($title) > 28) {
				$titlePost = substr($title, 0, 25)." ..";
			}else if (strlen($title) < 28){
				$titlePost = $title;
			}

			echo '<div id="wrap-result-generate">

					<div id="left-img-thumbnail-generate-result">
						<img src="'.$thumbnail.'">
					</div>
					<div id="text-description-result">
						<p id="title-result">'.$titlePost.'</p>
						<p id="method-download">Facebook</p>
						<a href="'.$url_download.'" download>
						<button id="btn-download" onclick="download()">
							DOWNLOAD
						</button>
						</a>
					</div>

				</div>';

		}


	}else if($urlVariable == "www.soundcloud.com" || $urlVariable == "soundcloud.com"){


		$apiGenerate = file_get_contents("http://www.owplus.com/api/downloader/generate?type=Soundcloud&url_input=".$urlInput."&api_code=".$apiKey."");
		$response = json_encode($apiGenerate);

		if($response == "false"){

			echo "Invalid URL!!, Please insert a valid url.";

		}else{

			$obj = json_decode($apiGenerate);

			$thumbnail = $obj->result->thumbnail;
			$title = $obj->result->title;
			$url_download = $obj->result->url_download;

			if (strlen($title) > 28) {
				$titlePost = substr($title, 0, 25)." ..";
			}else if (strlen($title) < 28){
				$titlePost = $title;
			}

			echo '<div id="wrap-result-generate">

					<div id="left-img-thumbnail-generate-result">
						<img src="'.$thumbnail.'">
					</div>
					<div id="text-description-result">
						<p id="title-result">'.$titlePost.'</p>
						<p id="method-download">Soundcloud</p>
						<a href="'.$url_download.'" download>
						<button id="btn-download" onclick="download()">
							DOWNLOAD
						</button>
						</a>
					</div>

				</div>';

		}



	}else{
		echo "Invalid URL!!, Please insert a valid url.";
	}



}

?>